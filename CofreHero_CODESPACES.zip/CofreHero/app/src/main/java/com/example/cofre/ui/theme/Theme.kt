package com.example.cofre.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val PxBg = Color(0xFF0B1020)
val PxPanel = Color(0xFF141B34)
val PxInk = Color(0xFF070B16)
val PxGold = Color(0xFFF5C542)
val PxGoldLight = Color(0xFFFFE88A)
val PxGoldDark = Color(0xFFC58F1A)
val PxBlue = Color(0xFF2F6FED)
val PxBlueDark = Color(0xFF1B3F9E)
val PxBlueLight = Color(0xFF8FC1FF)
val PxText = Color(0xFFF2F4FF)
val PxDim = Color(0xFFA9B3D6)
val PxDanger = Color(0xFFFF6B6B)

private val Mono = FontFamily.Monospace

private fun Typography.mono() = Typography(
    displayLarge = displayLarge.copy(fontFamily = Mono), displayMedium = displayMedium.copy(fontFamily = Mono),
    displaySmall = displaySmall.copy(fontFamily = Mono), headlineLarge = headlineLarge.copy(fontFamily = Mono),
    headlineMedium = headlineMedium.copy(fontFamily = Mono), headlineSmall = headlineSmall.copy(fontFamily = Mono),
    titleLarge = titleLarge.copy(fontFamily = Mono), titleMedium = titleMedium.copy(fontFamily = Mono),
    titleSmall = titleSmall.copy(fontFamily = Mono), bodyLarge = bodyLarge.copy(fontFamily = Mono),
    bodyMedium = bodyMedium.copy(fontFamily = Mono), bodySmall = bodySmall.copy(fontFamily = Mono),
    labelLarge = labelLarge.copy(fontFamily = Mono), labelMedium = labelMedium.copy(fontFamily = Mono),
    labelSmall = labelSmall.copy(fontFamily = Mono),
)

@Composable
fun CofreTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PxGold, onPrimary = PxInk, secondary = PxBlue, onSecondary = PxText,
            background = PxBg, onBackground = PxText, surface = PxPanel, onSurface = PxText,
            surfaceVariant = PxPanel, onSurfaceVariant = PxDim, error = PxDanger, outline = PxBlue,
        ),
        typography = Typography().mono(),
        content = content,
    )
}
