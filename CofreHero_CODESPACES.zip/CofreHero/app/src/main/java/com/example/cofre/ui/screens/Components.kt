package com.example.cofre.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.cofre.ui.theme.*
import com.example.cofre.ui.LocalSoundEngine
import com.example.cofre.data.SoundEvent

@Composable
fun PixelButton(text: String, modifier: Modifier = Modifier, gold: Boolean = true, enabled: Boolean = true, onClick: () -> Unit) {
    val sound = LocalSoundEngine.current
    Button(
        onClick = { sound.play(SoundEvent.BUTTON); onClick() }, modifier = modifier.height(52.dp), enabled = enabled, shape = RectangleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (gold) PxGold else PxBlue,
            contentColor = if (gold) PxInk else PxText,
        ),
        border = BorderStroke(2.dp, if (gold) PxGoldDark else PxBlueLight),
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
fun PixelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.border(2.dp, PxBlue).background(PxPanel).padding(12.dp), content = content)
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Volver", color = PxBlueLight, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(8.dp))
        Text(title, color = PxGold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun PixelField(value: String, onChange: (String) -> Unit, label: String, decimal: Boolean = false, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine,
        shape = RectangleShape, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PxGold, unfocusedBorderColor = PxBlue,
            focusedLabelColor = PxGold, cursorColor = PxGold,
        ),
    )
}

/** Barra segmentada de 20 bloques. progress ya viene acotado a 0..1. */
@Composable
fun PixelProgress(progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(26.dp)) {
        val n = 20
        val gap = 3.dp.toPx()
        val seg = (size.width - gap * (n - 1)) / n
        val filled = progress.coerceIn(0f, 1f) * n
        for (i in 0 until n) {
            val x = i * (seg + gap)
            drawRect(PxBlueDark.copy(alpha = 0.5f), Offset(x, 0f), Size(seg, size.height))
            val f = (filled - i).coerceIn(0f, 1f)
            if (f > 0f) drawRect(PxGold, Offset(x, 0f), Size(seg * f, size.height))
        }
        drawRect(PxBlue, style = Stroke(2.dp.toPx()))
    }
}

/** Resumen semanal: SALDO INICIAL / GASTADO / AHORRADO / DISPONIBLE. */
@Composable
fun WeekSummaryGrid(initial: Long, spent: Long, saved: Long, available: Long) {
    @Composable
    fun Cell(label: String, value: Long, color: androidx.compose.ui.graphics.Color, m: Modifier) {
        PixelCard(m) {
            Text(label, color = PxDim, style = MaterialTheme.typography.labelSmall)
            Text(com.example.cofre.core.Money.format(value), color = color, fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Cell("SALDO INICIAL", initial, PxText, Modifier.weight(1f))
            Cell("GASTADO", spent, PxDanger, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Cell("AHORRADO", saved, PxBlueLight, Modifier.weight(1f))
            Cell("DISPONIBLE", available, PxGold, Modifier.weight(1f))
        }
    }
}
